from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
from rasa_sdk.events import AllSlotsReset
from rasa_sdk.events import Restarted
from rasa_sdk import Action
from rasa_sdk.events import SlotSet

import json
import smtplib
import pprint, json
import pandas as pd
import requests


ZomatoData = pd.read_csv('zomato.csv')
ZomatoData = ZomatoData.drop_duplicates().reset_index(drop=True)
WeOperate = ['New Delhi', 'Gurgaon', 'Noida', 'Faridabad', 'Allahabad', 'Bhubaneshwar', 'Mangalore', 'Mumbai', 'Ranchi', 'Patna', 'Mysore', 'Aurangabad', 'Amritsar', 'Puducherry', 'Varanasi', 'Nagpur', 'Vadodara', 'Dehradun', 'Vizag', 'Agra', 'Ludhiana', 'Kanpur', 'Lucknow', 'Surat', 'Kochi', 'Indore', 'Ahmedabad', 'Coimbatore', 'Chennai', 'Guwahati', 'Jaipur', 'Hyderabad', 'Bangalore', 'Nashik', 'Pune', 'Kolkata', 'Bhopal', 'Goa', 'Chandigarh', 'Ghaziabad', 'Ooty', 'Gangtok', 'Shimla']
WeOperate_lower = [c.lower() for c in WeOperate]
WeOperate_lower += ['ahmedabad','bengaluru',' bangalore', 'chennai','madras', 'delhi','new delhi', 'hyderabad',
		 'kolkata', 'culcatta' ,'mumbai','bombay', 'pune', 'agra', 'ajmer','aligarh', 'amravati','amaravati', 'amritsar',
		  'asansol', 'aurangabad', 'bareilly', 'belgaum', 'bhavnagar', 'bhiwandi', 'bhopal',
		  'bhubaneswar', 'bikaner', 'bilaspur', 'bokaro', 'chandigarh', 'coimbatore',
		  'cuttack', 'dehradun', 'dhanbad', 'bhilai', 'durgapur', 'erode', 'faridabad',
		  'firozabad', 'ghaziabad', 'gorakhpur', 'gulbarga', 'guntur', 'gwalior', 'gurgaon',
		  'guwahati', 'hamirpur', 'hubli–dharwad', 'indore', 'jabalpur', 'jaipur', 'jalandhar',
		  'jammu', 'jamnagar', 'jamshedpur', 'jhansi', 'jodhpur', 'kakinada', 'kannur',
		  'kanpur', 'kochi', 'kolhapur', 'kollam', 'kozhikode', 'kurnool', 'ludhiana',
		  'lucknow', 'madurai', 'malappuram', 'mathura', 'goa', 'mangalore', 'meerut',
		  'moradabad', 'mysore', 'nagpur', 'nanded', 'nashik', 'nellore', 'noida', 'patna',
		  'pondicherry', 'purulia prayagraj', 'raipur', 'rajkot', 'rajahmundry', 'ranchi',
		  'rourkela', 'salem', 'sangli', 'shimla', 'siliguri', 'solapur', 'srinagar', 'surat',
		  'thiruvananthapuram', 'thrissur', 'tiruchirappalli', 'tiruppur', 'ujjain', 'bijapur',
		   'vadodara', 'varanasi', 'vasai-virar', 'vijayawada','vijaywada', 'visakhapatnam', 'vellore',
		   'warangal']

def RestaurantSearch(City,Cuisine,PriceMin,PriceMax):#Average Cost for two
	TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['City'].apply(lambda x: City.lower() in x.lower()))]
	TEMP = TEMP[TEMP['Average Cost for two'].apply(lambda x: PriceMin<= float(x) <=PriceMax)]
	if TEMP.shape[0]>0:
		TEMP = TEMP.sort_values(by='Aggregate rating',ascending=False)
	print(City,Cuisine,PriceMin,PriceMax,":",TEMP.shape)
	try:
		return TEMP[['Restaurant Name','Address','Average Cost for two','Aggregate rating']]
	except:
		return TEMP



res=''

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'


	def fetch(self,loc='banglore',cuisine='north indian',price='high'):
		print("#2")
		#adjust the price range
		price_min = 0
		price_max = 99999
		if price == 'low':
			price_max = 300
		elif price == 'mid':
			price_min = 300
			price_max = 700
		elif price == 'high':
			price_min = 700
		else:
			price_min = 300
			price_max = 9999


		# get_location gets the lat-long coordinates of 'loc'
		#if loc_detail['status'] == 'success':
		#data =  zomato.restaurant_search( query='', latitude=loc_detail['location_suggestions'][0]['latitude'], longitude=loc_detail['location_suggestions'][0]['longitude'], cuisines=str(cuisines_dict.get(cuisine)), limit=100)
		data = RestaurantSearch(loc,cuisine,price_min,price_max)#

		global res
		res = ''
		if data.shape[0] > 0:
			print("Found data.shape : ",data.shape)
			added=0
			for restaurant in data.iloc[:5].iterrows():
				restaurant = restaurant[1]
				if added <= 5:
					res = res + F"{restaurant['Restaurant Name']} in {restaurant['Address']} has been rated {restaurant['Aggregate rating']} \n"
					added = added +1
			if len(res) == 0:
				SlotSet('results_found',False)
				return "no results found"
		return "here are the results \n\n "+ res

		# else:
		# 	return 0





	def run(self, dispatcher, tracker, domain):
		#config={ "user_key":"f4924dc9ad672ee8c4f8c84743301af5"}
		#zomato = zomatopy.initialize_app(config)
		print("#1")
		loc = tracker.get_slot('location')
		print("Loc: ",loc)
		if loc == None:
			return dispatcher.utter_message('Location got is None')
		if loc.strip().lower() not in WeOperate_lower:
			dispatcher.utter_message("We don't operate in your location")
			return [AllSlotsReset()]
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')
		res=''
		if cuisine == None or price == None:
				dispatcher.utter_message("I didn't get all details, deafault results will be shown")
				cuisine = 'north'
				price = 'mid'

		else:
			res = self.fetch(loc,cuisine,price)
			dispatcher.utter_message(res+"\n\n\n")





class ActionSendEmail(Action):
	def name(self):
		return 'action_send_email'

	def fetch(self,loc='delhi',cuisine='north indian',price='high'):
		print("#Email-2")
		#adjust the price range
		price_min = 0
		price_max = 99999
		if price == 'low':
			price_max = 300
		elif price == 'mid':
			price_min = 300
			price_max = 700
		elif price == 'high':
			price_min = 700
		else:
			price_min = 300
			price_max = 9999


		# get_location gets the lat-long coordinates of 'loc'
		#if loc_detail['status'] == 'success':
		#data =  zomato.restaurant_search( query='', latitude=loc_detail['location_suggestions'][0]['latitude'], longitude=loc_detail['location_suggestions'][0]['longitude'], cuisines=str(cuisines_dict.get(cuisine)), limit=100)
		data = RestaurantSearch(loc,cuisine,price_min,price_max)#

		global res
		res = ''
		if data.shape[0] > 0:
			print("Email- Found data.shape : ",data.shape)
			added=0
			for restaurant in data.iloc[:10].iterrows():
				restaurant = restaurant[1]
				if added <= 10:
					res = res + F"{restaurant['Restaurant Name']} in {restaurant['Address']} has been rated {restaurant['Aggregate rating']} \n"
					added = added +1
			if len(res) == 0:
				SlotSet('results_found',False)
				return "no results found"
		return "here are the results \n\n "+ res





	def run(self, dispatcher, tracker, domain):
		print("#Email-1")
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')
		res = self.fetch(loc,cuisine,price)
		email = tracker.get_slot('email')
		if email == None:
			email = 'jansankumar.code@gmail.com'
		s = smtplib.SMTP('smtp.gmail.com', 587)
		s.starttls()
		#try:
		s.login("jansankumar.code@gmail.com", "Username5050@")
		# except:
		# 	dispatcher.utter_message('bad credentials, your preferences deleted')
		# 	return [AllSlotsReset()]
		message = "The details of top 10 restaurants you inquried \n \n"
		message = message + res
		try:
			s.sendmail("jansankumar.code@gmail.com", str(email), message)
			s.quit()
			dispatcher.utter_message("Email sent please check your inbox. your preferances will be deleted ")
			return [AllSlotsReset()]
		except:
			dispatcher.utter_message("Can't send the email. deleted your preferances")
			return [AllSlotsReset()]
