# Foodie-Chatbot
This is a chat-bot find best restaurants in your location. Uses Rasa framework and Zomato API. You can deploy it on online platforms like slack.

Please replicate the environment before running the code.

### pip3 install -r requirements.txt
